function initPortfolio() {
    let redrawRadarFn = null;

    // ===== DASHBOARD SIDEBAR & ROUTING =====
    const sidebar = document.getElementById('sidebar');
    const navToggle = document.getElementById('navToggle');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const navProgressFill = document.getElementById('nav-progress-fill');

    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('active');
        if (sidebarOverlay) sidebarOverlay.classList.remove('active');
        if (navToggle) navToggle.setAttribute('aria-expanded', 'false');
    }

    // Toggle sidebar on mobile
    if (navToggle && sidebar) {
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            const isOpen = sidebar.classList.toggle('active');
            if (sidebarOverlay) sidebarOverlay.classList.toggle('active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', () => {
            closeSidebar();
        });
    }

    // Close sidebar on click outside
    document.addEventListener('click', (e) => {
        if (sidebar && sidebar.classList.contains('active') && !sidebar.contains(e.target) && (navToggle && !navToggle.contains(e.target))) {
            closeSidebar();
        }
    });

    // ── setActiveLink: updates visual + ARIA state on all sidebar links ──
    function setActiveLink(targetId) {
        document.querySelectorAll('.sidebar-link').forEach(link => {
            const isActive = link.getAttribute('href') === targetId;
            link.classList.toggle('active', isActive);
            // aria-current="page" for screen readers; remove attribute when inactive
            if (isActive) {
                link.setAttribute('aria-current', 'page');
            } else {
                link.removeAttribute('aria-current');
            }
        });
    }

    // ── updateScrollProgress: fills the rail based on scroll within active section ──
    function updateScrollProgress() {
        if (!navProgressFill) return;
        const scrollTop = window.scrollY || document.documentElement.scrollTop;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const pct = docHeight > 0 ? Math.min(scrollTop / docHeight, 1) * 100 : 0;
        navProgressFill.style.height = pct + '%';
    }

    // ── switchSection: core routing function ──
    function switchSection(targetId) {
        const targetSection = document.querySelector(targetId);
        if (!targetSection) return;

        // Hide all sections
        document.querySelectorAll('.main-content section').forEach(section => {
            section.classList.remove('active-section');
        });

        // Show target section
        targetSection.classList.add('active-section');

        // Instantly activate reveal effects so user sees them animate immediately
        targetSection.querySelectorAll('.reveal, .reveal-stagger').forEach(el => {
            el.classList.add('active');
        });

        // Update active link + aria-current immediately (no waiting)
        setActiveLink(targetId);

        // Close sidebar on mobile after clicking
        closeSidebar();

        // Reset scroll position to top of section
        window.scrollTo({ top: 0, behavior: 'instant' });
        // Reset progress rail to 0 when switching sections
        updateScrollProgress();
        // Dispatch resize to force hidden canvases to recalculate
        window.dispatchEvent(new Event('resize'));
    }

    // Handle clicks on sidebar links
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId && targetId.startsWith('#')) {
                e.preventDefault();
                // Immediately mark as active before section animation starts
                setActiveLink(targetId);
                switchSection(targetId);
                // Update URL hash without jumping
                history.pushState(null, null, targetId);
            }
        });
    });

    // Handle clicks on in-content links like "View Projects" hero button
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        if (!link.classList.contains('sidebar-link')) {
            link.addEventListener('click', (e) => {
                const targetId = link.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                if (targetSection && targetSection.closest('.main-content')) {
                    e.preventDefault();
                    setActiveLink(targetId);
                    switchSection(targetId);
                    history.pushState(null, null, targetId);
                }
            });
        }
    });

    // Handle initial load hash router
    function handleHashRoute() {
        const hash = window.location.hash;
        if (hash) {
            switchSection(hash);
        } else {
            switchSection('#home');
        }
    }

    // Listen for hash change / load events
    window.addEventListener('hashchange', handleHashRoute);
    // Execute routing on startup
    handleHashRoute();

    // Click logo to go home
    document.querySelectorAll('.sidebar-logo, .mobile-logo').forEach(logo => {
        logo.addEventListener('click', () => {
            switchSection('#home');
            history.pushState(null, null, '#home');
        });
    });

    // ── Scroll progress rail: updates on scroll within the active section ──
    window.addEventListener('scroll', updateScrollProgress, { passive: true });
    updateScrollProgress(); // initialise

    // ===== INTERACTIVE CUSTOM CURSOR WITH LERP =====
    // Skip entirely on touch/mobile devices (no pointer cursor exists)
    const _isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    const cursor = document.getElementById('custom-cursor');
    const glow = document.getElementById('cursor-glow');
    let mouseX = 0, mouseY = 0;
    let cursorX = 0, cursorY = 0;
    let glowX = 0, glowY = 0;

    if (!_isTouchDevice) {
        document.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
        });

        function updateCursor() {
            cursorX += (mouseX - cursorX) * 0.15;
            cursorY += (mouseY - cursorY) * 0.15;
            glowX += (mouseX - glowX) * 0.06;
            glowY += (mouseY - glowY) * 0.06;

            if (cursor) {
                cursor.style.left = `${cursorX}px`;
                cursor.style.top = `${cursorY}px`;
            }
            if (glow) {
                glow.style.left = `${glowX}px`;
                glow.style.top = `${glowY}px`;
            }
            requestAnimationFrame(updateCursor);
        }
        requestAnimationFrame(updateCursor);

        // Hover elements interactions with cursor
        document.querySelectorAll('a, button, .skill-tag, .filter-tab, .project-card, .cert-card, .interactive-step, .interactive-edu-card').forEach(el => {
            el.addEventListener('mouseenter', () => {
                if (cursor) cursor.style.transform = 'translate(-50%, -50%) scale(1.8)';
                if (glow) glow.style.background = 'radial-gradient(circle, rgba(139, 92, 246, 0.22) 0%, transparent 70%)';
            });
            el.addEventListener('mouseleave', () => {
                if (cursor) cursor.style.transform = 'translate(-50%, -50%) scale(1)';
                if (glow) glow.style.background = 'radial-gradient(circle, rgba(6, 182, 212, 0.15) 0%, transparent 70%)';
            });
        });
    } else {
        if (cursor) cursor.style.display = 'none';
        if (glow) glow.style.display = 'none';
    }


    // ===== NETWORK TOPOLOGY BACKGROUND CANVAS =====
    const networkCanvas = document.getElementById('network-grid-canvas');
    if (networkCanvas) {
        const nCtx = networkCanvas.getContext('2d');
        const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        // Detect touch/mobile: no cursor interaction, fewer nodes
        const isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

        // ── Config ──────────────────────────────────────────────────────────
        const NODE_COUNT        = isTouchDevice ? 30 : 60;  // halved on mobile
        const CONNECT_DIST      = 150;         // px — max line distance
        const CONNECT_DIST_SQ   = CONNECT_DIST * CONNECT_DIST;
        const NODE_SPEED_MIN    = 0.18;        // px/frame
        const NODE_SPEED_MAX    = 0.55;
        const NODE_RADIUS       = 2.2;         // base dot size
        const NODE_COLOR        = '6, 182, 212';  // cyan RGB components
        const LINE_COLOR        = '6, 182, 212';
        const CURSOR_DIST       = 150;         // cursor interaction radius
        const CURSOR_DIST_SQ    = CURSOR_DIST * CURSOR_DIST;
        const REPEL_STRENGTH    = isTouchDevice ? 0 : 1.8;  // no repel on touch
        const REPEL_DECAY       = 0.88;        // velocity friction for repel
        const PULSE_INTERVAL_MIN = 3500;       // ms between random pulses
        const PULSE_INTERVAL_MAX = 7000;
        const PULSE_DURATION    = 1200;        // ms per pulse

        // ── State ────────────────────────────────────────────────────────────
        let W = 0, H = 0;
        let nodes = [];
        let mouseX = -9999, mouseY = -9999;
        let isTabVisible = !document.hidden;
        let rafId = null;
        let lastTs = 0;

        // ── DPR-aware resize ─────────────────────────────────────────────────
        function resize() {
            const dpr = window.devicePixelRatio || 1;
            W = window.innerWidth;
            H = window.innerHeight;
            networkCanvas.width  = W * dpr;
            networkCanvas.height = H * dpr;
            networkCanvas.style.width  = W + 'px';
            networkCanvas.style.height = H + 'px';
            nCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
        }
        resize();
        window.addEventListener('resize', resize);

        // ── Node class ───────────────────────────────────────────────────────
        class Node {
            constructor() { this.reset(true); }

            reset(randomPos) {
                if (randomPos) {
                    this.x = Math.random() * W;
                    this.y = Math.random() * H;
                } else {
                    // Enter from a random edge
                    const edge = Math.floor(Math.random() * 4);
                    if (edge === 0) { this.x = Math.random() * W; this.y = 0; }
                    else if (edge === 1) { this.x = W; this.y = Math.random() * H; }
                    else if (edge === 2) { this.x = Math.random() * W; this.y = H; }
                    else              { this.x = 0;  this.y = Math.random() * H; }
                }
                const speed = NODE_SPEED_MIN + Math.random() * (NODE_SPEED_MAX - NODE_SPEED_MIN);
                const angle = Math.random() * Math.PI * 2;
                this.vx = Math.cos(angle) * speed;
                this.vy = Math.sin(angle) * speed;
                this.rx = 0; this.ry = 0; // repulsion velocity
                this.baseAlpha = 0.55 + Math.random() * 0.35;
                this.pulseEnd  = 0;        // timestamp when current pulse ends
                this.r = NODE_RADIUS;
            }

            update(now) {
                if (prefersReducedMotion) return;
                // Apply repulsion then decay
                this.rx *= REPEL_DECAY;
                this.ry *= REPEL_DECAY;
                this.x += this.vx + this.rx;
                this.y += this.vy + this.ry;

                // Soft bounce at edges (margin = CONNECT_DIST/2 so connections
                // don't abruptly pop in/out at borders)
                const M = 5;
                if (this.x < M)      { this.x = M;   this.vx = Math.abs(this.vx); }
                if (this.x > W - M)  { this.x = W-M; this.vx = -Math.abs(this.vx); }
                if (this.y < M)      { this.y = M;   this.vy = Math.abs(this.vy); }
                if (this.y > H - M)  { this.y = H-M; this.vy = -Math.abs(this.vy); }
            }

            get isPulsing() { return performance.now() < this.pulseEnd; }

            draw(now) {
                const pulsing = this.isPulsing;
                const pulseProgress = pulsing
                    ? 1 - (this.pulseEnd - now) / PULSE_DURATION
                    : 0;
                // Pulse: grow bright then fade back
                const pulseGlow = pulsing
                    ? Math.sin(pulseProgress * Math.PI) // 0→1→0
                    : 0;
                const alpha = this.baseAlpha + pulseGlow * 0.4;
                const radius = this.r + pulseGlow * 3;

                // Glow halo
                if (pulseGlow > 0.05) {
                    const grad = nCtx.createRadialGradient(this.x, this.y, 0, this.x, this.y, radius * 5);
                    grad.addColorStop(0, `rgba(${NODE_COLOR}, ${pulseGlow * 0.35})`);
                    grad.addColorStop(1, `rgba(${NODE_COLOR}, 0)`);
                    nCtx.beginPath();
                    nCtx.arc(this.x, this.y, radius * 5, 0, Math.PI * 2);
                    nCtx.fillStyle = grad;
                    nCtx.fill();
                }

                // Core dot
                nCtx.beginPath();
                nCtx.arc(this.x, this.y, radius, 0, Math.PI * 2);
                nCtx.fillStyle = `rgba(${NODE_COLOR}, ${Math.min(alpha, 1)})`;
                nCtx.fill();
            }

            triggerPulse() {
                this.pulseEnd = performance.now() + PULSE_DURATION;
            }
        }

        // ── Build nodes ──────────────────────────────────────────────────────
        for (let i = 0; i < NODE_COUNT; i++) nodes.push(new Node());

        // ── Random node pulser ───────────────────────────────────────────────
        function schedulePulse() {
            if (prefersReducedMotion) return;
            const delay = PULSE_INTERVAL_MIN + Math.random() * (PULSE_INTERVAL_MAX - PULSE_INTERVAL_MIN);
            setTimeout(() => {
                if (nodes.length) {
                    nodes[Math.floor(Math.random() * nodes.length)].triggerPulse();
                }
                schedulePulse();
            }, delay);
        }
        schedulePulse();

        // ── Cursor tracking ──────────────────────────────────────────────────
        if (!prefersReducedMotion) {
            document.addEventListener('mousemove', (e) => {
                mouseX = e.clientX;
                mouseY = e.clientY;
            });
            document.addEventListener('mouseleave', () => { mouseX = -9999; mouseY = -9999; });
        }

        // ── Repulsion (throttled — runs only every other frame) ──────────────
        let repelFrame = 0;
        function applyRepulsion() {
            if (mouseX < -1000) return;
            for (let i = 0; i < nodes.length; i++) {
                const n = nodes[i];
                const dx = n.x - mouseX;
                const dy = n.y - mouseY;
                const distSq = dx * dx + dy * dy;
                if (distSq < CURSOR_DIST_SQ && distSq > 0) {
                    const dist = Math.sqrt(distSq);  // only when needed
                    const force = (CURSOR_DIST - dist) / CURSOR_DIST * REPEL_STRENGTH;
                    n.rx += (dx / dist) * force;
                    n.ry += (dy / dist) * force;
                }
            }
        }

        // ── Tab visibility pause ─────────────────────────────────────────────
        document.addEventListener('visibilitychange', () => {
            isTabVisible = !document.hidden;
            if (isTabVisible && !rafId) {
                lastTs = performance.now();
                rafId = requestAnimationFrame(draw);
            }
        });

        // ── Draw connections (cursor as virtual node) ────────────────────────
        function drawConnections() {
            const hasCursor = mouseX > -1000;
            nCtx.lineWidth = 0.7;

            // Node-to-node
            for (let i = 0; i < nodes.length; i++) {
                const a = nodes[i];
                for (let j = i + 1; j < nodes.length; j++) {
                    const b = nodes[j];
                    const dx = a.x - b.x;
                    const dy = a.y - b.y;
                    const distSq = dx * dx + dy * dy;
                    if (distSq < CONNECT_DIST_SQ) {
                        const alpha = (1 - distSq / CONNECT_DIST_SQ) * 0.18;
                        nCtx.strokeStyle = `rgba(${LINE_COLOR}, ${alpha})`;
                        nCtx.beginPath();
                        nCtx.moveTo(a.x, a.y);
                        nCtx.lineTo(b.x, b.y);
                        nCtx.stroke();
                    }
                }
                // Node-to-cursor
                if (hasCursor) {
                    const dx = a.x - mouseX;
                    const dy = a.y - mouseY;
                    const distSq = dx * dx + dy * dy;
                    if (distSq < CONNECT_DIST_SQ) {
                        const alpha = (1 - distSq / CONNECT_DIST_SQ) * 0.30;
                        nCtx.strokeStyle = `rgba(${LINE_COLOR}, ${alpha})`;
                        nCtx.beginPath();
                        nCtx.moveTo(a.x, a.y);
                        nCtx.lineTo(mouseX, mouseY);
                        nCtx.stroke();
                    }
                }
            }
        }

        // ── Draw cursor dot ──────────────────────────────────────────────────
        function drawCursorNode() {
            if (mouseX < -1000) return;
            nCtx.beginPath();
            nCtx.arc(mouseX, mouseY, NODE_RADIUS * 1.4, 0, Math.PI * 2);
            nCtx.fillStyle = `rgba(${NODE_COLOR}, 0.7)`;
            nCtx.fill();
        }

        // ── Main draw loop ───────────────────────────────────────────────────
        function draw(ts) {
            if (!isTabVisible) {
                rafId = null;
                return;
            }
            rafId = requestAnimationFrame(draw);

            const now = performance.now();
            nCtx.clearRect(0, 0, W, H);

            // Throttle repulsion to every other frame
            repelFrame++;
            if (!prefersReducedMotion && repelFrame % 2 === 0) applyRepulsion();

            // Update + draw
            drawConnections();
            for (const node of nodes) {
                node.update(now);
                node.draw(now);
            }
            drawCursorNode();
        }

        // Kick off — static single frame for reduced-motion, loop otherwise
        if (prefersReducedMotion) {
            // Render one static snapshot
            drawConnections();
            for (const node of nodes) node.draw(performance.now());
        } else {
            lastTs = performance.now();
            rafId = requestAnimationFrame(draw);
        }
    }


    // ===== ROLE TYPEWRITER SWITCHER LOOP =====
    const roleText = document.getElementById('role-text');
    const roles = [
        "AI-Powered Pipelines",
        "Full-Stack Software",
        "Cloud-Native Systems",
        "Agentic AI Workflows",
        "Solutions to Survive & Scale"
    ];
    let roleIdx = 0;
    let charIdx = 0;
    let isDeleting = false;
    let typeSpeed = 80;

    function typeRole() {
        if (!roleText) return;
        const currentRole = roles[roleIdx];
        if (isDeleting) {
            roleText.textContent = currentRole.substring(0, charIdx - 1);
            charIdx--;
            typeSpeed = 40;
        } else {
            roleText.textContent = currentRole.substring(0, charIdx + 1);
            charIdx++;
            typeSpeed = 100;
        }

        if (!isDeleting && charIdx === currentRole.length) {
            isDeleting = true;
            typeSpeed = 1800; // Pause at end of word
        } else if (isDeleting && charIdx === 0) {
            isDeleting = false;
            roleIdx = (roleIdx + 1) % roles.length;
            typeSpeed = 300; // Pause before starting new word
        }

        setTimeout(typeRole, typeSpeed);
    }
    if (roleText) {
        setTimeout(typeRole, 500);
    }

    // ===== STATS COUNTER AND OBSERVER =====
    // Automatically synchronize completed projects count from the #projects section
    function syncCompletedProjectsCount() {
        const totalProjects = document.querySelectorAll('#projects .project-card, .projects-grid .project-card');
        const projectStatNum = document.getElementById('stat-project-count') || document.querySelector('.achieve-card[href="#projects"] .achieve-num');
        const projectStatDesc = document.getElementById('stat-project-desc') || document.querySelector('.achieve-card[href="#projects"] .achieve-desc');
        
        if (totalProjects.length > 0) {
            const count = totalProjects.length;
            if (projectStatNum) {
                projectStatNum.setAttribute('data-target', count);
            }
            if (projectStatDesc) {
                projectStatDesc.textContent = `Built ${count} featured projects encompassing full-stack web platforms, edge serverless apps, data analytics, and IoT.`;
            }
        }
    }

    syncCompletedProjectsCount();

    // Observe changes in project grid to keep the count reactive if projects change dynamically
    const projectsGrid = document.querySelector('.projects-grid');
    if (projectsGrid) {
        const projObserver = new MutationObserver(() => {
            syncCompletedProjectsCount();
            const projectStatNum = document.getElementById('stat-project-count') || document.querySelector('.achieve-card[href="#projects"] .achieve-num');
            if (projectStatNum && projectStatNum.textContent !== '0') {
                const count = document.querySelectorAll('#projects .project-card, .projects-grid .project-card').length;
                projectStatNum.textContent = count + '+';
            }
        });
        projObserver.observe(projectsGrid, { childList: true });
    }

    function animateStatCounter(target) {
        const endVal = parseFloat(target.getAttribute('data-target'));
        const isFloat = endVal % 1 !== 0;
        const noPlus = target.getAttribute('data-no-plus') === 'true';
        const plusSuffix = noPlus ? "" : "+";
        let startVal = 0;
        const duration = 1500;
        const steps = 60;
        const stepTime = duration / steps;
        const increment = endVal / steps;
        let step = 0;

        const counter = setInterval(() => {
            step++;
            startVal += increment;
            if (step >= steps) {
                target.textContent = isFloat ? endVal.toFixed(2) + plusSuffix : endVal + plusSuffix;
                clearInterval(counter);
            } else {
                target.textContent = isFloat ? startVal.toFixed(2) + plusSuffix : Math.round(startVal) + plusSuffix;
            }
        }, stepTime);
    }

    const statNums = document.querySelectorAll('.stat-num, .achieve-num');
    const statsObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                animateStatCounter(target);
                observer.unobserve(target);
            }
        });
    }, { threshold: 0.5 });

    statNums.forEach(num => statsObserver.observe(num));

    // ===== 4-QUADRANT BENTO SKILL MATRIX INTERACTION =====
    const bentoQuadrants = document.querySelectorAll('.bento-quadrant');
    const skillCategories = document.querySelectorAll('.skill-category');

    if (bentoQuadrants.length) {
        // Bento quadrant hover triggers corresponding skill card highlight
        bentoQuadrants.forEach(quad => {
            quad.addEventListener('mouseenter', () => {
                const categoryClass = quad.getAttribute('data-category');
                skillCategories.forEach(card => {
                    if (card.classList.contains(categoryClass)) {
                        card.style.transform = 'translateY(-6px) scale(1.02)';
                        card.style.borderColor = 'var(--cyan)';
                        card.style.boxShadow = '0 12px 30px rgba(6, 182, 212, 0.3)';
                    }
                });
            });

            quad.addEventListener('mouseleave', () => {
                const categoryClass = quad.getAttribute('data-category');
                skillCategories.forEach(card => {
                    if (card.classList.contains(categoryClass)) {
                        card.style.transform = '';
                        card.style.borderColor = '';
                        card.style.boxShadow = '';
                    }
                });
            });
        });

        // Skill category card hover triggers corresponding bento quadrant highlight
        skillCategories.forEach(card => {
            card.addEventListener('mouseenter', () => {
                bentoQuadrants.forEach(quad => {
                    const quadCat = quad.getAttribute('data-category');
                    if (card.classList.contains(quadCat)) {
                        quad.classList.add('active');
                    }
                });
            });

            card.addEventListener('mouseleave', () => {
                bentoQuadrants.forEach(quad => {
                    quad.classList.remove('active');
                });
            });
        });
    }

    // ===== PROJECTS DISPLAY =====
    // Project category filter bar has been removed as requested.
    // All projects are displayed by default.





    // ===== SCROLL HIGHLIGHT =====
    // Navigation scroll highlighting is handled directly by the switchSection router.

    // ===== SCROLL REVEAL TRIGGERS =====
    const revealElements = document.querySelectorAll('.reveal, .reveal-stagger');
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, { threshold: 0.15 });

    revealElements.forEach(el => revealObserver.observe(el));

    // ===== TECH STACK ORBIT ENGINE & BACKGROUND CANVASES =====
    const orbitContainer = document.getElementById('orbit-container');
    const orbitRing = document.getElementById('orbit-ring');
    const orbitBgCanvas = document.getElementById('orbit-bg-canvas');
    const skillDescBox = document.getElementById('skill-desc-box');
    const skillDescText = document.getElementById('skill-desc-text');
    const infoIcon = skillDescBox ? skillDescBox.querySelector('.info-icon') : null;

    if (orbitContainer && orbitBgCanvas) {
        const oBgCtx = orbitBgCanvas.getContext('2d');
        const orbitItems = orbitContainer.querySelectorAll('.orbit-item');
        let isHoveringOrbit = false;
        let angleOffset = 0;

        // Tech descriptions mapping
        const techDetails = {
            vscode: "VS Code: Primary IDE. Custom styled with ESLint, Prettier, GitLens, and tailored python/debugging integrations.",
            nlp: "Natural Language Processing: Sentiment analysis models, TF-IDF vectorizers, word tokenization, and model transparency integrations.",
            python: "Python: Data analysis, scripting and automation, database integration, web scraping, and data manipulation using Pandas.",
            java: "Java: Solid object-oriented software engineering principles, system design patterns, and enterprise backend architectures.",
            javascript: "JavaScript & MERN Stack: Developing interactive web front-ends with React.js and engineering scalable backend services/APIs with Node.js & Express.",
            php: "PHP: Server-side scripting, dynamic web development, database-driven workflows, and REST API creation.",
            html5: "HTML5: Structuring clean semantic layouts with a focus on SEO best practices and page speed optimization.",
            css3: "CSS3: Formulating premium styling patterns, fluid animation keyframes, HSL color tokens, and robust layouts.",
            sql: "MySQL & MS SQL Server: Database operations, SQL scripting, schema engineering, backup reporting, and query optimization.",
            git: "Git & GitHub: Professional version control, branching strategies, repository management, collaborative PR code reviews, and workflow automation.",
            azure: "Microsoft Azure: Virtual network routing, resource group structures, role-based access lists, and cloud VM provisioning.",
            aks: "AKS (Azure Kubernetes Service): Orchestrating containerized deployments, Kubernetes cluster scaling, network routing, and config management.",
            docker: "Docker: Containerizing environments to guarantee 100% execution consistency from development to cloud hosting.",
            linux: "Linux Systems: System administration, bash shell scripting, job automation, and server patching management.",
            powerbi: "Power BI: Creating interactive executive business dashboards, advanced DAX queries, data transformations, and scheduled gateway refreshes.",
            excel: "Microsoft Excel: Advanced spreadsheets, pivot tables, VLOOKUP/INDEX-MATCH, VBA macros, and financial data modeling.",
            servicenow: "ServiceNow: Managing IT Service Management (ITSM) workflows, system incidents tracking, asset management, and ticketing workflows."
        };

        // Brand colors mapping for dynamic hover styles
        const brandColors = {
            vscode: "#007ACC",
            nlp: "#A855F7",
            python: "#3776AB",
            java: "#5382A1",
            javascript: "#F7DF1E",
            php: "#777BB4",
            html5: "#E34F26",
            css3: "#1572B6",
            sql: "#00758F",
            git: "#f3f4f6",
            azure: "#0078D4",
            aks: "#326CE5",
            docker: "#2496ED",
            linux: "#FCC624",
            powerbi: "#F2C811",
            excel: "#107C41",
            servicenow: "#81B924"
        };

        let isLockedOrbit = false;

        function showTechDetails(tech) {
            const text = techDetails[tech] || "Exploring premium software engineering capabilities.";
            const color = brandColors[tech] || "var(--cyan)";
            
            if (skillDescText) {
                skillDescText.style.opacity = '0';
                setTimeout(() => {
                    skillDescText.textContent = text;
                    skillDescText.style.opacity = '1';
                    skillDescText.style.color = 'var(--text-main)';
                }, 150);
            }
            
            if (skillDescBox) {
                skillDescBox.classList.add('active');
                skillDescBox.style.borderColor = color;
                skillDescBox.style.boxShadow = `0 0 15px ${color}33`; // 33 is alpha in hex (20%)
            }
            if (infoIcon) {
                infoIcon.style.color = color;
                infoIcon.style.transform = 'scale(1.2) rotate(10deg)';
            }
        }

        function clearTechDetails() {
            if (skillDescText) {
                skillDescText.style.opacity = '0';
                setTimeout(() => {
                    skillDescText.textContent = "Hover over any technology to explore my experience.";
                    skillDescText.style.opacity = '1';
                    skillDescText.style.color = 'var(--text-muted)';
                }, 150);
            }
            
            if (skillDescBox) {
                skillDescBox.classList.remove('active');
                skillDescBox.style.borderColor = 'var(--glass-border)';
                skillDescBox.style.boxShadow = 'none';
            }
            if (infoIcon) {
                infoIcon.style.color = 'var(--cyan)';
                infoIcon.style.transform = 'scale(1) rotate(0deg)';
            }
        }

        // Hover functionality
        orbitItems.forEach(item => {
            item.addEventListener('mouseenter', () => {
                if (isLockedOrbit) return;
                const tech = item.getAttribute('data-tech');
                showTechDetails(tech);
                isHoveringOrbit = true;
            });

            item.addEventListener('mouseleave', () => {
                if (isLockedOrbit) return;
                clearTechDetails();
                isHoveringOrbit = false;
            });

            // Touch events for mobile/tablet
            item.addEventListener('touchstart', (e) => {
                e.stopPropagation(); // prevent document touchstart handler from clearing it
                const tech = item.getAttribute('data-tech');
                
                // Toggle lock/unlock if tapping same item
                if (isLockedOrbit && item.classList.contains('locked-active')) {
                    item.classList.remove('locked-active');
                    clearTechDetails();
                    isHoveringOrbit = false;
                    isLockedOrbit = false;
                } else {
                    orbitItems.forEach(el => el.classList.remove('locked-active'));
                    item.classList.add('locked-active');
                    showTechDetails(tech);
                    isHoveringOrbit = true;
                    isLockedOrbit = true;
                }
            });
        });

        // Document-level touchstart to unlock
        document.addEventListener('touchstart', (e) => {
            if (isLockedOrbit) {
                if (!orbitContainer.contains(e.target)) {
                    orbitItems.forEach(el => el.classList.remove('locked-active'));
                    clearTechDetails();
                    isHoveringOrbit = false;
                    isLockedOrbit = false;
                }
            }
        });

        // Background canvas dimensions
        function resizeOrbitCanvas() {
            orbitBgCanvas.width = orbitContainer.clientWidth;
            orbitBgCanvas.height = orbitContainer.clientHeight;
        }
        resizeOrbitCanvas();
        window.addEventListener('resize', resizeOrbitCanvas);

        // Particle configuration for background
        const orbitParticles = [];
        const maxParticles = 25;
        
        class OrbitBgParticle {
            constructor() {
                this.x = Math.random() * orbitBgCanvas.width;
                this.y = Math.random() * orbitBgCanvas.height;
                this.speedX = (Math.random() - 0.5) * 0.15;
                this.speedY = (Math.random() - 0.5) * 0.15;
                this.radius = Math.random() * 1.5 + 0.5;
            }
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                if (this.x < 0) this.x = orbitBgCanvas.width;
                if (this.x > orbitBgCanvas.width) this.x = 0;
                if (this.y < 0) this.y = orbitBgCanvas.height;
                if (this.y > orbitBgCanvas.height) this.y = 0;
            }
        }

        for (let i = 0; i < maxParticles; i++) {
            orbitParticles.push(new OrbitBgParticle());
        }

        // Animation Loop
        function animateOrbit() {
            const centerX = orbitContainer.clientWidth / 2;
            const centerY = orbitContainer.clientHeight / 2;
            
            // Adjust radii dynamically based on container size (safeguarded against 0 or negative values)
            const rx = Math.max(80, Math.min(centerX - 85, 420));
            const ry = Math.max(40, Math.min(centerY - 55, 150));

            // Update orbit path line size
            if (orbitRing) {
                orbitRing.style.width = `${rx * 2}px`;
                orbitRing.style.height = `${ry * 2}px`;
            }

            // Draw Background Particles & faint lines
            oBgCtx.clearRect(0, 0, orbitBgCanvas.width, orbitBgCanvas.height);
            
            // Draw grid mapping lines on background
            oBgCtx.strokeStyle = 'rgba(255, 255, 255, 0.006)';
            oBgCtx.lineWidth = 1;
            const gridSpacing = 40;
            for (let x = 0; x < orbitBgCanvas.width; x += gridSpacing) {
                oBgCtx.beginPath();
                oBgCtx.moveTo(x, 0);
                oBgCtx.lineTo(x, orbitBgCanvas.height);
                oBgCtx.stroke();
            }
            for (let y = 0; y < orbitBgCanvas.height; y += gridSpacing) {
                oBgCtx.beginPath();
                oBgCtx.moveTo(0, y);
                oBgCtx.lineTo(orbitBgCanvas.width, y);
                oBgCtx.stroke();
            }

            // Draw drifting stars
            orbitParticles.forEach(p => {
                p.update();
                oBgCtx.beginPath();
                oBgCtx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                oBgCtx.fillStyle = 'rgba(6, 182, 212, 0.12)';
                oBgCtx.fill();
            });

            // Symmetrically distribute all items around the circle (equally distributed in layout)
            const N = orbitItems.length;
            orbitItems.forEach((item, index) => {
                const theta = (index / N) * Math.PI * 2 + angleOffset;
                
                // Base calculations for x, y
                let x = rx * Math.cos(theta);
                let y = ry * Math.sin(theta);
                
                // Depth effects
                const depth = Math.sin(theta);
                let scale = 0.8 + 0.3 * ((depth + 1) / 2);
                const zIndex = Math.round(10 + 10 * depth);
                const opacity = 0.45 + 0.55 * ((depth + 1) / 2);
                
                // De-emphasize ServiceNow, Excel, and Power BI
                const cat = item.getAttribute('data-category') || 'general';
                if (cat === 'general') {
                    scale *= 0.75;
                    x *= 1.15;
                    y *= 1.15;
                }
                
                item.style.transform = `translate(-50%, -50%) translate(${x}px, ${y}px) scale(${scale})`;
                item.style.zIndex = zIndex;
                item.style.opacity = opacity;
                
                // Draw connecting dotted line to center
                oBgCtx.strokeStyle = document.body.classList.contains('light-theme') ? 'rgba(0, 0, 0, 0.12)' : 'rgba(6, 182, 212, 0.22)';
                oBgCtx.lineWidth = 1;
                oBgCtx.setLineDash([4, 4]);
                oBgCtx.beginPath();
                oBgCtx.moveTo(centerX, centerY);
                oBgCtx.lineTo(centerX + x, centerY + y);
                oBgCtx.stroke();
            });

            // Increment angle offset (pause or slow down on hover/lock)
            if (isLockedOrbit) {
                // Pause rotation completely
            } else if (isHoveringOrbit) {
                angleOffset += 0.0003;
            } else {
                angleOffset += 0.0018;
            }

            requestAnimationFrame(animateOrbit);
        }

        requestAnimationFrame(animateOrbit);
    }

    // ===== STATIC GALLERY LIGHTBOX SYSTEM =====
    function initLightbox() {
        const lightbox = document.getElementById("photoLightbox");
        const closeBtn = document.querySelector(".lightbox-close");

        if (closeBtn && lightbox) {
            closeBtn.addEventListener("click", () => {
                lightbox.style.display = "none";
            });
            lightbox.addEventListener("click", (e) => {
                if (e.target === lightbox) {
                    lightbox.style.display = "none";
                }
            });
        }
    }

    function openLightbox(imgUrl, caption) {
        const lightbox = document.getElementById("photoLightbox");
        const lightboxImg = document.getElementById("lightboxImage");
        const lightboxCaption = document.getElementById("lightboxCaption");

        if (lightbox && lightboxImg && lightboxCaption) {
            lightbox.style.display = "block";
            lightboxImg.src = imgUrl;
            lightboxCaption.innerText = caption;
        }
    }

    function initStaticGallery() {
        const galleryImgs = document.querySelectorAll(".vol-gallery-item img");
        galleryImgs.forEach(img => {
            img.addEventListener("click", () => {
                openLightbox(img.src, img.alt);
            });
        });
    }

    // Initialize photo features
    initLightbox();
    initStaticGallery();


    // ===== INTERACTIVE RESUME MODAL =====
    const resumeModal = document.getElementById('resumeModal');
    const viewResumeBtn = document.getElementById('viewResumeBtn');
    const heroResumeBtn = document.getElementById('heroResumeBtn');
    const closeResumeBtn = document.getElementById('closeResumeBtn');

    function openResumeModal(e) {
        if (e) e.preventDefault();
        if (resumeModal) {
            resumeModal.classList.add('active');
            document.body.style.overflow = 'hidden';

            // Mobile UA check to show download fallback
            const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            const iframe = document.getElementById('resume-iframe');
            const fallback = document.getElementById('pdf-mobile-fallback');

            if (isMobile && iframe && fallback) {
                iframe.style.display = 'none';
                fallback.style.display = 'block';
            } else if (iframe && fallback) {
                iframe.style.display = 'block';
                fallback.style.display = 'none';
            }
        }
    }

    function closeResumeModal() {
        if (resumeModal) {
            resumeModal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    if (viewResumeBtn) {
        viewResumeBtn.addEventListener('click', openResumeModal);
    }
    if (heroResumeBtn) {
        heroResumeBtn.addEventListener('click', openResumeModal);
    }
    if (closeResumeBtn) {
        closeResumeBtn.addEventListener('click', closeResumeModal);
    }

    if (resumeModal) {
        resumeModal.addEventListener('click', (e) => {
            if (e.target === resumeModal) {
                closeResumeModal();
            }
        });
    }

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && resumeModal && resumeModal.classList.contains('active')) {
            closeResumeModal();
        }
    });

    // ===== INTERACTIVE COURSE DETAILS ACCORDION =====
    const courseItems = document.querySelectorAll('.courses-ul .course-item');
    courseItems.forEach(item => {
        // Add tabindex for keyboard accessibility
        item.setAttribute('tabindex', '0');

        item.addEventListener('click', () => {
            const isActive = item.classList.contains('active-course');
            const parentUl = item.closest('.courses-ul');
            if (parentUl) {
                parentUl.querySelectorAll('.course-item').forEach(c => c.classList.remove('active-course'));
            } else {
                courseItems.forEach(c => c.classList.remove('active-course'));
            }
            if (!isActive) {
                item.classList.add('active-course');
            }
        });

        // Keypress accessibility: enter or space to expand course drawers
        item.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                item.click();
            }
        });
    });

    // ===== INTERACTIVE AI ASSISTANT WIDGET LOGIC =====
    const chatbotTrigger = document.getElementById('chatbotTrigger');
    const chatbotWindow = document.getElementById('chatbotWindow');
    const chatbotCloseBtn = document.getElementById('chatbotCloseBtn');
    const chatbotMessages = document.getElementById('chatbotMessages');
    const chatbotInput = document.getElementById('chatbotInput');
    const chatbotSendBtn = document.getElementById('chatbotSendBtn');
    const suggestionChips = document.querySelectorAll('.suggestion-chip');

    const botResponses = {
        skills: "Myat combines technical engineering with real-world business execution across data science, AI-powered systems, and cloud operations:\n\n" +
                "🛠️ **Technical & Web Development:**\n" +
                "• Python, JavaScript, PHP, React.js, Node.js, HTML/CSS, Git/GitHub, MS SQL, Microsoft Azure, Linux fundamentals\n\n" +
                "📊 **Data & Analytics:**\n" +
                "• Data analysis, report generation, supervised machine learning, SQL, spreadsheet modelling\n\n" +
                "💼 **Operations & Administration:**\n" +
                "• Business operations, inventory tracking, event coordination, logistics, Microsoft Excel/Office, data entry\n\n" +
                "🤝 **Soft Skills & Leadership:**\n" +
                "• Mentoring/teaching, customer service, fluent English, team leadership, cross-functional collaboration\n\n" +
                "🔗 View his work in the [Featured Projects](#projects) section or explore the [Skills Ecosystem](#skills) to learn more.",
        experience: "Myat has hands-on experience across enterprise cloud operations, entrepreneurship, and tech events:\n\n" +
                    "💼 **AIA Digital +** — *Cloud Operations intern* (Apr 2026 – Present)\n" +
                    "Supported MySQL & Microsoft SQL Server database operations, Windows/Linux infrastructure patching, ITSM ServiceNow workflows, and enterprise tools including Microsoft Azure, Dynatrace, PagerDuty, and CyberArk.\n\n" +
                    "💼 **Print With Sahel** — *Founder and Owner* (Apr 2024 – Feb 2026)\n" +
                    "Founded and ran an on-campus print service, managing daily order fulfillment, urgent deadline scheduling, cash flow, paper/ink supplies, and machine maintenance.\n\n" +
                    "🤝 **Extracurricular & Volunteering:**\n" +
                    "• **Kedah Maker Fair 2025:** Committee Member & Event Organizer (66 school teams)\n" +
                    "• **Young Innovators Challenge 2025 (Chumbaka):** Mentor & Trainer (Arduino IoT & AI)\n\n" +
                    "🔗 View his full timeline in the [Experience Section](#experience) or click to [View CV PDF](CV_MMK.pdf).",
        references: "Myat provides three verified academic and industry references:\n\n" +
                    "1. **Mark Virta** — Director of Technology Operations, AIA Digital+ Malaysia\n" +
                    "   📧 [Mark.Virta@aia.com](mailto:Mark.Virta@aia.com)\n\n" +
                    "2. **Professor Dr. Basheer Riskhan** — Dean and Lecturer, Albukhary International University\n" +
                    "   📧 [b.riskhan@aiu.edu.my](mailto:b.riskhan@aiu.edu.my)\n\n" +
                    "3. **Associate Prof Ts. Dr. Leelavathi Rajamanickam** — Lecturer, Albukhary International University\n" +
                    "   📧 [leelavathi.rajamanickam@aiu.edu.my](mailto:leelavathi.rajamanickam@aiu.edu.my)\n\n" +
                    "🔗 View verified references in the [Experience & References](#experience) section.",
        projects: "Here are Myat's featured projects:\n\n" +
                  "1. **Kedah Community Connect (KCC)** — Cloud-first, serverless civic issue reporting & service tracking platform ([Live Demo](https://kedah-community-connect-kcc.vercel.app/)) (React 18, Hono, Cloudflare Workers/D1/R2, RBAC, 12 Kedah districts).\n" +
                  "2. **AIU Postgraduate Monitoring System** (Final Year Project) — Multi-user platform supporting 500+ users with RBAC user journey validation.\n" +
                  "3. **Smart Greenhouse Monitoring System (IoT)** — ESP32 sensor integration, edge threshold logic, and MQTT ThingsBoard telemetry.\n" +
                  "4. **Handwriting Recognition Project** — CNN writer classifier (70 classes) for offline CPU-only execution with prediction CSV & confusion matrix.\n" +
                  "5. **ChatGPT App Review Analyzer (NLP)** — Scikit-Learn NLP pipeline benchmarking Linear SVM, Naive Bayes, and Logistic Regression on 2,290+ reviews (80.22% peak accuracy).\n\n" +
                  "🔗 Explore the full interactive gallery in the [Featured Projects](#projects) section!",
        status: "📍 **Career Availability Status:**\n" +
                "• **Target Roles:** Data Analysis, Agentic AI, Software Development, Graduate Trainee\n" +
                "• **Work Types:** Full-Time, Part-Time, Contract, Freelance, or Graduate Trainee\n" +
                "• **Timeline:** Preferably starting **December 2026** and **January 2027**\n" +
                "• **Location:** Kuala Lumpur, Malaysia (Open to On-site work, Relocation, and Remote work)\n\n" +
                "🔗 Reach out directly via the [Contact Form](#contact) or message via [WhatsApp Direct](https://wa.me/601164597291)!",
        contact: "You can reach Myat directly via these channels:\n\n" +
                 "📧 **Email:** mmk111203@gmail.com\n" +
                 "📞 **Phone:** +601164597291\n" +
                 "💼 **LinkedIn:** linkedin.com/in/myat-min-khant-810bb3275\n" +
                 "📂 **GitHub:** github.com/myatminkhant123\n\n" +
                 "🔗 Or message him directly via [WhatsApp Direct](https://wa.me/601164597291) or submit the [Contact Form](#contact)!",
        education: "Myat holds a **Bachelor of Computer Science (Honours)** (CGPA 3.53) and **Foundation in Computing** (CGPA 3.27) from **Albukhary International University (AIU)** as an **Albukhary Foundation Fully Funded Scholarship Recipient**.\n\n" +
                   "• **Certifications:** IBM Certified Data Analyst Professional, Generative AI for Software Development (DeepLearning.AI), and TechNexus Full MERN Stack Bootcamp.\n\n" +
                   "🔗 Credentials verification: [IBM Professional Certificate](https://coursera.org/verify/professional-cert/CLPHAOPC673C), [DeepLearning.AI Certificate](https://coursera.org/verify/professional-cert/TRP5PIXN0JQS), and [TechNexus MERN Stack Bootcamp](technexus_cert.png)."
    };

    function toggleChatbot() {
        if (chatbotWindow) {
            chatbotWindow.classList.toggle('active');
            if (chatbotWindow.classList.contains('active') && chatbotInput) {
                chatbotInput.focus();
            }
        }
    }

    function addMessage(text, sender) {
        if (!chatbotMessages) return;

        const msgDiv = document.createElement('div');
        msgDiv.className = `chat-message ${sender}`;
        
        let formattedText = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\[(.*?)\]\((.*?)\)/g, (match, linkText, url) => {
                if (url.startsWith('#')) {
                    return `<a href="${url}" class="chat-link scroll-link">${linkText}</a>`;
                }
                return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="chat-link">${linkText}</a>`;
            })
            .replace(/\n/g, '<br>');
        
        msgDiv.innerHTML = formattedText;
        
        // Add scroll-link click listeners to close chatbot and scroll smoothly
        msgDiv.querySelectorAll('.scroll-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href');

                if (chatbotWindow) {
                    chatbotWindow.classList.remove('active');
                }

                if (targetId && targetId.startsWith('#') && document.querySelector(targetId)) {
                    setActiveLink(targetId);
                    switchSection(targetId);
                    history.pushState(null, null, targetId);
                }
            });
        });

        chatbotMessages.appendChild(msgDiv);
        
        chatbotMessages.scrollTo({
            top: chatbotMessages.scrollHeight,
            behavior: 'smooth'
        });
    }

    function getBotResponse(userMsg) {
        const text = userMsg.toLowerCase().trim();
        
        if (text.includes('skill') || text.includes('tech') || text.includes('stack') || text.includes('python') || text.includes('code') || text.includes('program') || text.includes('php')) {
            return botResponses.skills;
        } else if (text.includes('ref') || text.includes('virta') || text.includes('riskhan') || text.includes('leelavathi') || text.includes('recommend') || text.includes('supervisor')) {
            return botResponses.references;
        } else if (text.includes('project') || text.includes('greenhouse') || text.includes('chatgpt') || text.includes('handwriting') || text.includes('aiu') || text.includes('kedah') || text.includes('kcc') || text.includes('aduan') || text.includes('civic')) {
            return botResponses.projects;
        } else if (text.includes('exp') || text.includes('work') || text.includes('job') || text.includes('intern') || text.includes('aia') || text.includes('sahel')) {
            return botResponses.experience;
        } else if (text.includes('status') || text.includes('avail') || text.includes('relocat') || text.includes('timelin') || text.includes('where') || text.includes('locat')) {
            return botResponses.status;
        } else if (text.includes('contact') || text.includes('email') || text.includes('phone') || text.includes('linkedin') || text.includes('github') || text.includes('reach')) {
            return botResponses.contact;
        } else if (text.includes('study') || text.includes('edu') || text.includes('uni') || text.includes('degree') || text.includes('college') || text.includes('cert')) {
            return botResponses.education;
        } else if (text.includes('hello') || text.includes('hi') || text.includes('hey') || text.includes('greet')) {
            return "Hello! I'm Myat's portfolio assistant. Ask about his **skills**, **projects**, **experience**, **references**, **education**, **availability**, or **contact info**!";
        } else {
            return "I can answer questions regarding Myat's **skills**, **projects**, **experience**, **references**, **education**, **availability**, or **contact info**. Feel free to try any of these keywords!";
        }
    }

    function handleUserSend() {
        if (!chatbotInput) return;
        const text = chatbotInput.value.trim();
        if (!text) return;

        addMessage(text, 'user');
        chatbotInput.value = '';

        setTimeout(() => {
            const reply = getBotResponse(text);
            addMessage(reply, 'bot');
        }, 600);
    }

    if (chatbotTrigger) {
        chatbotTrigger.addEventListener('click', toggleChatbot);
    }
    if (chatbotCloseBtn) {
        chatbotCloseBtn.addEventListener('click', toggleChatbot);
    }

    if (chatbotSendBtn) {
        chatbotSendBtn.addEventListener('click', handleUserSend);
    }

    if (chatbotInput) {
        chatbotInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                handleUserSend();
            }
        });
    }

    suggestionChips.forEach(chip => {
        chip.addEventListener('click', () => {
            const questionKey = chip.getAttribute('data-question');
            const questionText = chip.textContent;
            
            addMessage(questionText, 'user');
            
            setTimeout(() => {
                const reply = botResponses[questionKey] || "I don't have information on that yet.";
                addMessage(reply, 'bot');
            }, 500);
        });
    });

    // ===== INTERACTIVE CODE WINDOW TABS =====
    const codeTabs = document.querySelectorAll('.code-tab');
    const codeContainers = document.querySelectorAll('.code-body-container');
    const terminalWindow = document.getElementById('terminal-window');
    const runCodeBtn = document.getElementById('run-code-btn');

    codeTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            codeTabs.forEach(t => t.classList.remove('active'));
            // Hide all code bodies
            codeContainers.forEach(container => container.style.display = 'none');

            // Close terminal if open
            if (terminalWindow) {
                terminalWindow.classList.remove('active');
            }
            clearTimeouts();
            if (runCodeBtn) {
                runCodeBtn.disabled = false;
            }
            isRunningSim = false;

            // Add active class to clicked tab
            tab.classList.add('active');
            // Show corresponding code body
            const fileType = tab.getAttribute('data-file');
            const targetContainer = document.getElementById(`code-${fileType}`);
            if (targetContainer) {
                targetContainer.style.display = 'block';
            }
        });
    });

    // ===== INTERACTIVE TERMINAL SIMULATION =====
    const terminalClose = document.getElementById('terminal-close');
    const terminalBody = document.getElementById('terminal-body');
    let isRunningSim = false;
    let typeTimeouts = [];

    function clearTimeouts() {
        typeTimeouts.forEach(t => clearTimeout(t));
        typeTimeouts = [];
    }

    if (runCodeBtn && terminalWindow && terminalBody) {
        runCodeBtn.addEventListener('click', () => {
            if (isRunningSim) return;
            
            // Disable button during execution
            runCodeBtn.disabled = true;
            isRunningSim = true;

            // Clear previous simulation run
            clearTimeouts();
            terminalWindow.classList.add('active');
            terminalBody.innerHTML = '';

            // Find currently active file type
            const activeTab = document.querySelector('.code-tab.active');
            const fileType = activeTab ? activeTab.getAttribute('data-file') : 'ts';

            // Extract variables dynamically from contenteditable fields
            const sequences = {};

            if (fileType === 'ts') {
                const spec1 = document.getElementById('edit-ts-spec1')?.textContent.trim() || 'Software Engineering';
                const spec2 = document.getElementById('edit-ts-spec2')?.textContent.trim() || 'Data Analytics';
                const spec3 = document.getElementById('edit-ts-spec3')?.textContent.trim() || 'Cloud Operations';
                
                sequences.ts = [
                    { text: "$ npx ts-node workflow.ts", type: "cmd" },
                    { text: "[INFO] Initializing compilation context for developer 'Myat Min Khant'...", type: "info" },
                    { text: `[INFO] Specialties verified: ["${spec1}", "${spec2}", "${spec3}"]`, type: "info" },
                    { text: "[INFO] Running async DataProcessor operations on raw input...", type: "info" },
                    { text: "[SUCCESS] Scalable FullStackApplication successfully deployed to production (scaling: auto, reliability: 99.9%).", type: "success" }
                ];
            } else if (fileType === 'py') {
                const focus1 = document.getElementById('edit-py-focus1')?.textContent.trim() || 'Software Engineering';
                const focus2 = document.getElementById('edit-py-focus2')?.textContent.trim() || 'Data Science';
                
                sequences.py = [
                    { text: "$ python analytics.py", type: "cmd" },
                    { text: "[INFO] Loading Pandas DataFrame workflow...", type: "info" },
                    { text: `[INFO] Analyzing data patterns: focus set to ["${focus1}", "${focus2}"]`, type: "info" },
                    { text: "[INFO] Running transform_and_analyze() operations...", type: "info" },
                    { text: "[SUCCESS] PortfolioWorkflow execution output: FullStackApp deployed. scale_out=True.", type: "success" }
                ];
            } else if (fileType === 'sql') {
                const skill1 = document.getElementById('edit-sql-skill1')?.textContent.trim() || 'Software Engineering';
                const skill2 = document.getElementById('edit-sql-skill2')?.textContent.trim() || 'Data Analytics';
                const skill3 = document.getElementById('edit-sql-skill3')?.textContent.trim() || 'Cloud Operations';
                
                sequences.sql = [
                    { text: "$ psql -f insights.sql", type: "cmd" },
                    { text: "[INFO] Executing SELECT query on database table 'aiu_graduates'...", type: "info" },
                    { text: `[INFO] Filtering constraints: skills IN ('${skill1}', '${skill2}', '${skill3}')`, type: "info" },
                    { text: "[INFO] Fetching records sorted by impact_level DESC...", type: "info" },
                    { text: "[SUCCESS] Query complete: 1 record fetched (Myat Min Khant - Scalable & Reliable Systems) in 42ms.", type: "success" }
                ];
            }

            const lines = sequences[fileType] || [];
            let lineIdx = 0;

            function printNextLine() {
                if (lineIdx >= lines.length) {
                    // Enable run button again
                    runCodeBtn.disabled = false;
                    isRunningSim = false;
                    return;
                }
                
                const lineData = lines[lineIdx];
                const lineDiv = document.createElement('div');
                lineDiv.className = `terminal-line terminal-${lineData.type}`;
                terminalBody.appendChild(lineDiv);
                
                // Typewriter effect for text
                let charIdx = 0;
                function typeChar() {
                    if (charIdx < lineData.text.length) {
                        lineDiv.textContent += lineData.text[charIdx];
                        charIdx++;
                        terminalBody.scrollTop = terminalBody.scrollHeight;
                        typeTimeouts.push(setTimeout(typeChar, lineData.type === 'cmd' ? 25 : 12));
                    } else {
                        lineIdx++;
                        typeTimeouts.push(setTimeout(printNextLine, 300));
                    }
                }
                typeChar();
            }
            printNextLine();
        });
    }

    if (terminalClose && terminalWindow) {
        terminalClose.addEventListener('click', () => {
            terminalWindow.classList.remove('active');
            clearTimeouts();
            if (runCodeBtn) {
                runCodeBtn.disabled = false;
            }
            isRunningSim = false;
        });
    }

    // ===== 3D TILT HOVER EFFECT FOR PROJECT CARDS =====
    const projectCards = document.querySelectorAll('.project-card');

    projectCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const cardRect = card.getBoundingClientRect();
            
            // Calculate mouse position relative to card center (range -0.5 to 0.5)
            const mouseX = (e.clientX - cardRect.left) / cardRect.width - 0.5;
            const mouseY = (e.clientY - cardRect.top) / cardRect.height - 0.5;
            
            // Degrees of rotation (max 10deg)
            const rotateX = -mouseY * 12;
            const rotateY = mouseX * 12;
            
            // Translate slightly towards the user
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
        });
    });

    // ===== CONTACT FORM TERMINAL SIMULATION =====
    const contactForm = document.getElementById('contactForm');
    const formTerminalOverlay = document.getElementById('formTerminalOverlay');
    const formTerminalBody = document.getElementById('formTerminalBody');
    const formTerminalClose = document.getElementById('form-terminal-close');
    let formTimeouts = [];

    function clearFormTimeouts() {
        formTimeouts.forEach(t => clearTimeout(t));
        formTimeouts = [];
    }

    // Typewriter print helper for sequential async terminal logs
    function printFormTerminalLine(text, type) {
        return new Promise((resolve) => {
            const lineDiv = document.createElement('div');
            lineDiv.className = `terminal-line terminal-${type}`;
            formTerminalBody.appendChild(lineDiv);
            
            let charIdx = 0;
            function typeChar() {
                if (charIdx < text.length) {
                    lineDiv.textContent += text[charIdx];
                    charIdx++;
                    formTerminalBody.scrollTop = formTerminalBody.scrollHeight;
                    const delay = type === 'cmd' ? 25 : 12;
                    formTimeouts.push(setTimeout(typeChar, delay));
                } else {
                    formTimeouts.push(setTimeout(resolve, 350));
                }
            }
            typeChar();
        });
    }

    if (contactForm && formTerminalOverlay && formTerminalBody) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const visitorName = document.getElementById('name').value.trim() || 'Visitor';
            const visitorEmail = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();

            // Show overlay
            formTerminalOverlay.classList.add('active');
            formTerminalBody.innerHTML = '';
            clearFormTimeouts();

            try {
                await printFormTerminalLine(`$ git push secure-smtp visitor-message --author="${visitorName}"`, 'cmd');
                await printFormTerminalLine("[INFO] Packaging communication payload...", 'info');
                await printFormTerminalLine("[INFO] Connecting to remote server mail.myatminkhant.dev...", 'info');
                await printFormTerminalLine("[INFO] Establishing secure TLS 1.3 channel...", 'info');
                await printFormTerminalLine("[INFO] Transmitting encrypted message payload...", 'info');
                
                // Contact API via Fetch request
                const response = await fetch('https://api.web3forms.com/submit', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        access_key: "d666c9c0-1339-4a3a-9a96-7f74ca7f3018",
                        name: visitorName,
                        email: visitorEmail,
                        subject: subject,
                        message: message
                    })
                });
                
                const data = await response.json();
                
                if (response.ok && data.success) {
                    await printFormTerminalLine(`[SUCCESS] Message successfully delivered to Myat's inbox! Thank you, ${visitorName}!`, 'success');
                    showToast("Message Transmitted", `Thank you, ${visitorName}! Your message reached Myat's inbox.`);
                    formTimeouts.push(setTimeout(() => {
                        contactForm.reset();
                    }, 1000));
                } else {
                    throw new Error(data.message || "Remote SMTP server rejected credentials check authorization.");
                }
            } catch (error) {
                await printFormTerminalLine(`[ERROR] Transmission failed: ${error.message}`, 'error');
                await printFormTerminalLine("[ERROR] Git push rejected. Secure mail channel closed.", 'error');
            }
        });
    }

    if (formTerminalClose && formTerminalOverlay) {
        formTerminalClose.addEventListener('click', () => {
            formTerminalOverlay.classList.remove('active');
            clearFormTimeouts();
        });
    }

    // ===== DARK/LIGHT THEME SWITCHER =====
    const themeToggleSidebar = document.getElementById('themeToggleSidebar');
    const themeToggleMobile = document.getElementById('themeToggleMobile');

    function toggleTheme() {
        const isLightTheme = document.body.classList.toggle('light-theme');
        localStorage.setItem('theme', isLightTheme ? 'light' : 'dark');
        updateThemeIcons(isLightTheme);
        if (redrawRadarFn) {
            redrawRadarFn();
        }
    }

    function updateThemeIcons(isLight) {
        const toggleButtons = [themeToggleSidebar, themeToggleMobile];
        toggleButtons.forEach(btn => {
            if (btn) {
                const icon = btn.querySelector('i');
                if (icon) {
                    if (isLight) {
                        icon.className = 'fa-solid fa-sun';
                        btn.style.color = '#eab308';
                    } else {
                        icon.className = 'fa-solid fa-moon';
                        btn.style.color = '';
                    }
                }
            }
        });
    }

    if (themeToggleSidebar) themeToggleSidebar.addEventListener('click', toggleTheme);
    if (themeToggleMobile) themeToggleMobile.addEventListener('click', toggleTheme);

    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        updateThemeIcons(true);
    }

    // ===== PROJECT CATEGORY FILTERING =====
    const filterButtons = document.querySelectorAll('.project-filter-btn');

    if (filterButtons.length > 0 && projectCards && projectCards.length > 0) {
        filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                filterButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                const filterValue = btn.getAttribute('data-filter');

                projectCards.forEach(card => {
                    const categories = card.getAttribute('data-categories') || '';
                    const categoryList = categories.split(' ');

                    if (filterValue === 'all' || categoryList.includes(filterValue)) {
                        card.classList.remove('is-hidden');
                    } else {
                        card.classList.add('is-hidden');
                    }
                });
            });
        });
    }

    // ===== TOAST NOTIFICATION HELPER =====
    function showToast(title, message) {
        const toast = document.getElementById('toastNotification');
        const tTitle = document.getElementById('toastTitle');
        const tMsg = document.getElementById('toastMessage');
        if (toast && tTitle && tMsg) {
            tTitle.textContent = title;
            tMsg.textContent = message;
            toast.classList.add('active');
            setTimeout(() => toast.classList.remove('active'), 4500);
        }
    }

    // ===== ACCENT THEME PICKER =====
    const accentDots = document.querySelectorAll('.accent-dot');
    function setAccent(accentName) {
        accentDots.forEach(dot => {
            dot.classList.toggle('active', dot.getAttribute('data-accent') === accentName);
        });
        if (accentName === 'cyan') {
            document.documentElement.removeAttribute('data-accent');
            document.body.removeAttribute('data-accent');
        } else {
            document.documentElement.setAttribute('data-accent', accentName);
            document.body.setAttribute('data-accent', accentName);
        }
        localStorage.setItem('accentColor', accentName);
    }
    accentDots.forEach(dot => {
        dot.addEventListener('click', () => {
            const acc = dot.getAttribute('data-accent');
            setAccent(acc);
        });
    });
    const savedAccent = localStorage.getItem('accentColor');
    if (savedAccent) setAccent(savedAccent);

    // ===== INTERACTIVE TERMINAL CLI =====
    const terminalCliInput = document.getElementById('terminal-cli-input');
    if (terminalCliInput && terminalBody) {
        terminalCliInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const cmd = terminalCliInput.value.trim().toLowerCase();
                terminalCliInput.value = '';
                if (!cmd) return;

                const cmdLine = document.createElement('div');
                cmdLine.className = 'terminal-line terminal-cmd';
                cmdLine.textContent = `$ ${cmd}`;
                terminalBody.appendChild(cmdLine);

                const resLine = document.createElement('div');
                resLine.className = 'terminal-line terminal-info';

                switch (cmd) {
                    case 'help':
                        resLine.textContent = '[HELP] Available commands: help, skills, projects, experience, references, whoami, clear, contact';
                        break;
                    case 'skills':
                        resLine.textContent = '[SKILLS] Tech: Python, JavaScript, PHP, React.js, Node.js, HTML/CSS | Data: Supervised ML, MS SQL, MySQL, Analytics | Cloud: Microsoft Azure, Linux';
                        break;
                    case 'projects':
                        resLine.textContent = '[PROJECTS] 1) Kedah Community Connect (Cloudflare Serverless/React 18) 2) AIU Postgraduate System (500+ users) 3) Smart Greenhouse (IoT/ThingsBoard) 4) Handwriting Classifier (CNN) 5) ChatGPT Review Analyzer (NLP)';
                        break;
                    case 'experience':
                        resLine.textContent = '[EXPERIENCE] AIA Digital+ (Cloud Operations Intern, Apr 2026–Present) | Print With Sahel (Founder & Owner, Apr 2024–Feb 2026)';
                        break;
                    case 'references':
                        resLine.textContent = '[REFERENCES] 1) Mark Virta (Director Tech Ops, AIA Digital+) 2) Prof. Dr. Basheer Riskhan (Dean, AIU) 3) Assoc. Prof. Ts. Dr. Leelavathi Rajamanickam (AIU)';
                        break;
                    case 'whoami':
                        resLine.textContent = '[WHOAMI] Myat Min Khant — Computer Science Graduate (Data Science & AI) | Albukhary Foundation Scholar (CGPA 3.53) | AIA Digital+ Cloud Ops';
                        break;
                    case 'contact':
                        resLine.textContent = '[CONTACT] Email: mmk111203@gmail.com | Phone: +601164597291 | Location: Kuala Lumpur, Malaysia | LinkedIn: /in/myat-min-khant-810bb3275/';
                        break;
                    case 'clear':
                        terminalBody.innerHTML = '';
                        return;
                    default:
                        resLine.className = 'terminal-line terminal-error';
                        resLine.textContent = `[ERROR] Command not recognized: '${cmd}'. Type 'help' for available commands.`;
                }
                terminalBody.appendChild(resLine);
                terminalBody.scrollTop = terminalBody.scrollHeight;
            }
        });
    }

    // ===== QUICK PREVIEW MODAL =====
    const previewModal = document.getElementById('projectPreviewModal');
    const closePreviewBtn = document.getElementById('closePreviewModalBtn');
    const previewModalTitle = document.getElementById('previewModalTitle');
    const previewModalImg = document.getElementById('previewModalImg');
    const previewModalDesc = document.getElementById('previewModalDesc');
    const previewModalTech = document.getElementById('previewModalTech');
    const previewModalCodeBtn = document.getElementById('previewModalCodeBtn');
    const previewModalDemoBtn = document.getElementById('previewModalDemoBtn');

    document.querySelectorAll('.preview-modal-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (!previewModal) return;
            previewModalTitle.textContent = btn.getAttribute('data-title') || 'Project Preview';
            previewModalDesc.textContent = btn.getAttribute('data-desc') || '';
            previewModalImg.src = btn.getAttribute('data-img') || '';
            
            const techString = btn.getAttribute('data-tech') || '';
            previewModalTech.innerHTML = techString.split(',').map(t => `<span class="tech-tag">${t.trim()}</span>`).join(' ');
            
            const codeUrl = btn.getAttribute('data-code');
            const demoUrl = btn.getAttribute('data-demo');
            
            if (codeUrl) {
                previewModalCodeBtn.style.display = 'inline-flex';
                previewModalCodeBtn.href = codeUrl;
            } else {
                previewModalCodeBtn.style.display = 'none';
            }
            
            if (demoUrl) {
                previewModalDemoBtn.style.display = 'inline-flex';
                previewModalDemoBtn.href = demoUrl;
            } else {
                previewModalDemoBtn.style.display = 'none';
            }
            
            previewModal.classList.add('active');
        });
    });

    if (closePreviewBtn && previewModal) {
        closePreviewBtn.addEventListener('click', () => previewModal.classList.remove('active'));
        previewModal.addEventListener('click', (e) => {
            if (e.target === previewModal) previewModal.classList.remove('active');
        });
    }

    // ===== LIVE GITHUB DATA FETCH =====
    const GH_LANG_COLORS = {
        Python: '#3776AB',
        JavaScript: '#F7DF1E',
        TypeScript: '#3178C6',
        HTML: '#E34F26',
        CSS: '#1572B6',
        Java: '#E76F51',
        'Jupyter Notebook': '#DA5B0B',
        SQL: '#CC292B',
        Shell: '#89E051',
    };

    function renderGitHubLanguages(langCounts) {
        const bar = document.getElementById('gh-lang-bar');
        const legend = document.getElementById('gh-lang-legend');
        if (!bar || !legend) return;

        const total = Object.values(langCounts).reduce((sum, n) => sum + n, 0);
        if (total <= 0) return;

        const sorted = Object.entries(langCounts)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 4);

        bar.innerHTML = sorted.map(([lang, count]) => {
            const pct = Math.round((count / total) * 100);
            const color = GH_LANG_COLORS[lang] || '#9ca3af';
            return `<div class="gh-bar-segment" style="width: ${pct}%; background: ${color};" title="${lang} ${pct}%"></div>`;
        }).join('');

        legend.innerHTML = sorted.map(([lang, count]) => {
            const pct = Math.round((count / total) * 100);
            const color = GH_LANG_COLORS[lang] || '#9ca3af';
            return `<span><span class="dot" style="background: ${color};"></span> ${lang} (${pct}%)</span>`;
        }).join('');
    }

    async function fetchGitHubStats() {
        try {
            const res = await fetch('https://api.github.com/users/myatminkhant123');
            if (res.ok) {
                const data = await res.json();
                const reposEl = document.getElementById('gh-metric-repos');
                const followersEl = document.getElementById('gh-metric-followers');
                const sinceEl = document.getElementById('gh-metric-since');
                if (reposEl) reposEl.textContent = `${data.public_repos}+`;
                if (followersEl) followersEl.textContent = `${data.followers}+`;
                if (sinceEl && data.created_at) {
                    sinceEl.textContent = new Date(data.created_at).getFullYear();
                }
            }

            const reposRes = await fetch('https://api.github.com/users/myatminkhant123/repos?per_page=100&sort=updated');
            if (reposRes.ok) {
                const repos = await reposRes.json();
                const langCounts = {};
                repos.forEach((repo) => {
                    if (repo.fork || !repo.language) return;
                    langCounts[repo.language] = (langCounts[repo.language] || 0) + 1;
                });
                renderGitHubLanguages(langCounts);
            }
        } catch (e) {
            // Silently retain fallback values
        }
    }
    fetchGitHubStats();

    // ===== COURSE ACCORDION A11Y KEYBOARD ACCESSIBILITY =====
    document.querySelectorAll('.course-item-header').forEach(header => {
        header.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                header.click();
                const isExpanded = header.getAttribute('aria-expanded') === 'true';
                header.setAttribute('aria-expanded', (!isExpanded).toString());
            }
        });
    });

    document.querySelectorAll('a[target="_blank"]:not([rel])').forEach((anchor) => {
        anchor.rel = 'noopener noreferrer';
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPortfolio);
} else {
    initPortfolio();
}